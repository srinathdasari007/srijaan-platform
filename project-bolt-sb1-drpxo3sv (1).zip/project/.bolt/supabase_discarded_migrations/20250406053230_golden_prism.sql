/*
  # Update email notification trigger

  1. Changes
    - Updates the email notification trigger to use SMTP configuration
    - Adds proper error handling and logging
  
  2. Security
    - Maintains existing RLS policies
    - Uses secure email configuration
*/

-- First, let's create a function to handle SMTP email sending
CREATE OR REPLACE FUNCTION send_smtp_email(
  p_to text,
  p_subject text,
  p_body text
) RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_config email_config;
BEGIN
  -- Get the email configuration
  SELECT * INTO v_config FROM email_config LIMIT 1;
  
  -- Send email using pg_net
  PERFORM net.http_post(
    url := 'https://api.mailchannels.net/tx/v1/send',
    headers := jsonb_build_object(
      'content-type', 'application/json'
    ),
    body := jsonb_build_object(
      'from', jsonb_build_object(
        'email', v_config.smtp_username,
        'name', 'Contact Form'
      ),
      'to', jsonb_build_array(
        jsonb_build_object(
          'email', v_config.admin_email,
          'name', 'Admin'
        )
      ),
      'subject', p_subject,
      'content', jsonb_build_array(
        jsonb_build_object(
          'type', 'text/plain',
          'value', p_body
        )
      )
    )
  );
  
  RETURN true;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error
    RAISE NOTICE 'Error sending email: %', SQLERRM;
    RETURN false;
END;
$$;

-- Now, let's update the contact submission trigger
CREATE OR REPLACE FUNCTION notify_new_contact_submission()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_subject text;
  v_body text;
BEGIN
  -- Prepare email content
  v_subject := 'New Contact Form Submission';
  v_body := format(
    'New contact form submission received:

Name: %s
Email: %s
Message: %s

Submitted at: %s',
    NEW.name,
    NEW.email,
    NEW.message,
    NEW.created_at
  );

  -- Send the email
  IF NOT send_smtp_email(
    (SELECT admin_email FROM email_config LIMIT 1),
    v_subject,
    v_body
  ) THEN
    RAISE WARNING 'Failed to send email notification for contact submission %', NEW.id;
  END IF;

  -- Update the submission status
  UPDATE contact_submissions
  SET status = CASE 
    WHEN send_smtp_email(
      (SELECT admin_email FROM email_config LIMIT 1),
      v_subject,
      v_body
    ) THEN 'email_sent'
    ELSE 'email_failed'
  END
  WHERE id = NEW.id;

  RETURN NEW;
END;
$$;

-- Recreate the trigger
DROP TRIGGER IF EXISTS contact_submission_notification ON contact_submissions;
CREATE TRIGGER contact_submission_notification
  AFTER INSERT ON contact_submissions
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_contact_submission();

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pg_net;