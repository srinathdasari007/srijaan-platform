/*
  # Add email notification trigger

  1. Changes
    - Creates a function to send email notifications
    - Adds a trigger to automatically send emails for new submissions
  
  2. Security
    - Function runs with security definer to access email_config
    - Maintains existing RLS policies
*/

-- Create the notification function
CREATE OR REPLACE FUNCTION notify_new_contact_submission()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  email_settings email_config;
BEGIN
  -- Get email configuration
  SELECT * INTO email_settings FROM email_config LIMIT 1;

  -- Send email using pg_net extension
  PERFORM net.http_post(
    url:='https://api.sendgrid.com/v3/mail/send',
    headers:=jsonb_build_object(
      'Authorization', 'Bearer ' || email_settings.smtp_password,
      'Content-Type', 'application/json'
    ),
    body:=jsonb_build_object(
      'personalizations', jsonb_build_array(
        jsonb_build_object(
          'to', jsonb_build_array(
            jsonb_build_object(
              'email', email_settings.admin_email
            )
          )
        )
      ),
      'from', jsonb_build_object(
        'email', email_settings.smtp_username
      ),
      'subject', 'New Contact Form Submission',
      'content', jsonb_build_array(
        jsonb_build_object(
          'type', 'text/plain',
          'value', format(
            'New contact form submission:%s%sName: %s%sEmail: %s%sMessage: %s',
            E'\n\n', E'\n', NEW.name, E'\n', NEW.email, E'\n', NEW.message
          )
        )
      )
    )
  );

  RETURN NEW;
END;
$$;

-- Create the trigger
DROP TRIGGER IF EXISTS contact_submission_notification ON contact_submissions;
CREATE TRIGGER contact_submission_notification
  AFTER INSERT ON contact_submissions
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_contact_submission();

-- Enable the pg_net extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_net;