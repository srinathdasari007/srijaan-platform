/*
  # Update email configuration

  Updates the email configuration with actual SMTP details for sending notifications.
  
  1. Changes
     - Updates SMTP configuration with real values
     - Sets admin email for receiving notifications
  
  2. Security
     - No changes to existing RLS policies
     - Email config remains protected by service role only policy
*/

UPDATE email_config
SET 
  smtp_hostname = 'smtp.gmail.com',
  smtp_username = 'your.email@gmail.com',  -- Replace with your actual Gmail
  smtp_password = 'your-app-password',     -- Replace with your actual App Password
  admin_email = 'your.email@gmail.com',    -- Replace with your actual email
  updated_at = now()
WHERE id = (SELECT id FROM email_config LIMIT 1);