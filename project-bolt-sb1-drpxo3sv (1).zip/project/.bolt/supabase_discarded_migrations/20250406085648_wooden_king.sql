/*
  # Revert email configuration to working state
  
  1. Changes
     - Removes secondary_emails column
     - Restores original working configuration
*/

-- Remove secondary_emails column if it exists
ALTER TABLE email_config 
DROP COLUMN IF EXISTS secondary_emails;

-- Restore original working configuration
UPDATE email_config
SET 
  smtp_hostname = 'smtp.gmail.com',
  smtp_username = 'marketing.srijaan@gmail.com',
  smtp_password = 'nmzc cwyv lvfb whbj',
  admin_email = 'marketing.srijaan@gmail.com',
  updated_at = now()
WHERE id = (SELECT id FROM email_config LIMIT 1);