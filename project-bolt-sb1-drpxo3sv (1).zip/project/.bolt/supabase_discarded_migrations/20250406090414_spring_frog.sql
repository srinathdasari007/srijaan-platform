/*
  # Set up storage for image uploads
  
  1. Changes
     - Creates a new storage bucket for images
     - Sets up proper security policies
     - Configures file size limits and allowed types
  
  2. Security
     - Public read access
     - Authenticated users can upload and delete
     - File size limited to 5MB
     - Only allows image file types
*/

DO $$
BEGIN
    -- Create bucket if it doesn't exist
    INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    VALUES (
        'images',
        'images',
        true,
        5242880, -- 5MB in bytes
        ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp']::text[]
    )
    ON CONFLICT (id) DO UPDATE
    SET 
        public = EXCLUDED.public,
        file_size_limit = EXCLUDED.file_size_limit,
        allowed_mime_types = EXCLUDED.allowed_mime_types;

    -- Set up storage policies
    -- Public read access
    INSERT INTO storage.policies (name, definition, bucket_id)
    VALUES (
        'Public Read Access',
        'bucket_id = ''images''',
        'images'
    )
    ON CONFLICT (name, bucket_id) DO NOTHING;

    -- Authenticated users upload policy
    INSERT INTO storage.policies (name, definition, bucket_id)
    VALUES (
        'Authenticated Users Upload',
        'bucket_id = ''images'' AND auth.role() = ''authenticated''',
        'images'
    )
    ON CONFLICT (name, bucket_id) DO NOTHING;

    -- Authenticated users delete policy
    INSERT INTO storage.policies (name, definition, bucket_id)
    VALUES (
        'Authenticated Users Delete',
        'bucket_id = ''images'' AND auth.role() = ''authenticated''',
        'images'
    )
    ON CONFLICT (name, bucket_id) DO NOTHING;
END $$;