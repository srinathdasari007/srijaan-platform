/*
  # Update email configuration

  Updates the email configuration with the actual Gmail credentials.
  
  1. Changes
     - Updates SMTP username (Gmail address)
     - Updates SMTP password (Gmail App Password)
     - Updates admin email
*/

UPDATE email_config
SET 
  smtp_username = current_setting('app.smtp_username', true),  -- Will be set via environment variable
  smtp_password = current_setting('app.smtp_password', true),  -- Will be set via environment variable
  admin_email = current_setting('app.admin_email', true),     -- Will be set via environment variable
  updated_at = now()
WHERE id = (SELECT id FROM email_config LIMIT 1);