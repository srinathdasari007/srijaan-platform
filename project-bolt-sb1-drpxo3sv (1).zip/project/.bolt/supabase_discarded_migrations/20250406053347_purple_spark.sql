/*
  # Update contact submissions RLS policy

  1. Changes
    - Updates RLS policy to allow public inserts properly
    - Maintains security while allowing form submissions
  
  2. Security
    - Enables public access for inserts only
    - Maintains authenticated-only access for viewing submissions
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow insert for all" ON contact_submissions;
DROP POLICY IF EXISTS "Authenticated users can view submissions" ON contact_submissions;

-- Create new policies with proper security
CREATE POLICY "Enable public form submissions" ON contact_submissions
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to view submissions" ON contact_submissions
  FOR SELECT
  TO authenticated
  USING (true);