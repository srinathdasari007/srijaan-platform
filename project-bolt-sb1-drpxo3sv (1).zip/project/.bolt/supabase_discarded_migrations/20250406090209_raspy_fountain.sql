/*
  # Fix storage policies for logo uploads
  
  1. Changes
     - Updates storage policies to fix permissions
     - Ensures proper bucket configuration
  
  2. Security
     - Maintains public read access
     - Restricts write access to authenticated users
*/

-- Recreate the bucket with proper settings
DO $$
BEGIN
    -- Delete existing policies
    DELETE FROM storage.policies WHERE bucket_id = 'logos';
    
    -- Update bucket settings
    UPDATE storage.buckets 
    SET public = true,
        file_size_limit = 5242880,
        allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/gif']::text[]
    WHERE id = 'logos';

    -- Create new policies with correct definitions
    INSERT INTO storage.policies (name, definition, bucket_id)
    VALUES
    ('Public Read Access', 
     'bucket_id = ''logos''', 
     'logos'),
    ('Authenticated Users Upload',
     'bucket_id = ''logos'' AND auth.role() = ''authenticated''',
     'logos'),
    ('Authenticated Users Delete',
     'bucket_id = ''logos'' AND auth.role() = ''authenticated''',
     'logos');
END $$;