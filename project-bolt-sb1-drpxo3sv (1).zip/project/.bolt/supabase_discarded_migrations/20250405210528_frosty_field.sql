/*
  # Update email configuration

  1. Changes
    - Updates the email configuration with Gmail SMTP settings
    - Sets up email notifications for contact form submissions

  2. Security
    - Maintains existing RLS policies
    - Only service role can access email configuration
*/

UPDATE email_config
SET 
  smtp_hostname = 'smtp.gmail.com',
  smtp_username = 'youremail@gmail.com',  -- Replace with your Gmail address
  smtp_password = 'your-16-char-app-password', -- Replace with your App Password
  admin_email = 'youremail@gmail.com',    -- Replace with your Gmail address
  updated_at = now()
WHERE id = (SELECT id FROM email_config LIMIT 1);